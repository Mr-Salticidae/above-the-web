# 全片 v3.1 封版存档 · 工作日志（2026-06-16）

> 性质：口播稿大改 + 视觉重写的封版 checkpoint。明日继续调优。
> 当前状态：**provisional（估算 timing）预览态，未生成真实 Eleven 音频。**

## 今天完成

1. **P0（motion 重锚）**：以 `fullFilmVoiceoverTiming` 为时间真相，build 时把 motion 重锚到真实 beat。修复"动画时长靠估算"错位。已单独提交（`413815c`）+ 旧版全片重渲染验证通过。
2. **诊断旧版节奏问题**：作者独白占 49%（107s/216s）喧宾夺主；53 个等长卡片=节拍器；比喻接力无落地。结合 Kurzgesagt / 知识科普脚本规律。
3. **v3.1 口播稿锁定**（`full_film_2026-06-16_script_v3.1_locked.md`）：
   - 母题：**助产(maieutic) ↔ 尸检(postmortem)**，《流浪地球2》"完整的一生"串联。
   - 贯穿案例：**真实双题复盘翻车**（票数靠前未获奖，却被记成"获奖图复盘"，AI 放大成 11 条假经验）。
   - 砍掉技术栈点名 / Codex 总指挥 / 工业化愿景 / "无产阶级铡刀"。作者独白 107s → ~18s。
4. **代码重写**：
   - `fullFilmVoiceover.ts`：23 beat（旧 53），新音频目录 `audio/full_film_20260616`。
   - `sceneSpecs.ts`：9 个新场景（生死框架→法医铁律→真实翻车→冻结事实→.md形态→三误区→一生收束→作者话），复用现有 subject/layout/motion，无新组件。
   - 静音预览管线：`scripts/estimate-full-film-timing.ts`（字数估算 timing，hasGeneratedAudio=false）+ `FullFilmVoiceoverAudio` 静音守卫 + `FullFilmBgmAudio` 作者段锚点改 `author_01_cant_edit` + `generate-full-film-voiceover.ts` 改用 `fullFilmVoiceover.audioPublicDir`。
   - typecheck 通过；6 张预览抽帧确认新结构 on-message（est 总长 ~154s / 2:34）。

## 明日接续（resume）

**第一步：生成真实 Eleven 音频（用户付费步骤）**
```
# 确认 .env 有 ELEVENLABS_API_KEY 与 ELEVENLABS_VOICE_ID
cd "E:\knowledge-base\07_skill存档\remotion"
npm.cmd run generate:full-film-voiceover
```
- 会把 23 段 mp3 写入 `public/audio/full_film_20260616/`，并用**真实时长**覆盖 `fullFilmVoiceoverTiming.ts`（hasGeneratedAudio=true）。
- motion 自动重锚（P0），无需手调动画。

**第二步：渲染真片审节奏**
```
npx.cmd remotion render src/index.ts SkillIsAllYouNeedFullFilm out/full-film-20260616-v3.1.mp4
```
真实节奏只有这一步能 faithful 判定（估算 timing 不算数）。

## 待办 / 开放项

- [ ] 真实音频生成后，审听节奏，按"长短碎交替"继续微调 beat 切分。
- [ ] 旧 6 张 MJ 图是给旧脚本的，新场景需重做 MJ/Seedance（P1，节奏定稿后）。
- [ ] 小瑕疵：warning-icon 三角下方白色标签在浅底偏淡，可改深色描边。
- [ ] BGM：双曲拼接仍在，新片更短，取段点/音量待随新节奏微调。

## 续：2026-06-27（真实音频 + 真片渲染）

> 时隔搁置，周末续推。把 6-16 checkpoint 的「明日接续」两步实际跑完。

1. **真实 Eleven 音频已生成**：`npm run generate:full-film-voiceover` → 23 段 mp3 落 `public/audio/full_film_20260616/`（2.5M）；`fullFilmVoiceoverTiming.ts` 已写回 `hasGeneratedAudio=true`，真实 `totalFrames=4792`（≈2:40，比估算 2:34 略长）。motion 随 P0 自动重锚。
2. **真片已渲染**：`out/full-film-20260616-v3.1.mp4`（14.1M / 1920×1080 / h264 + AAC 立体声，含配音 + 双曲 BGM）。
3. **视觉抽帧验过**（t=4/75/130/150s）：中文渲染、扁平矢量布局、字幕、重锚 motion 均正常。冷开场/冻结事实/完整一生闭环/作者话开源结尾四处 on-message。
4. **gitignore**：镜像 20260609 先例，白名单放行 `full_film_20260616/`，把这批付费音频入库（保护不丢失 + 可复现，呼应"代码开源"主题）。

### take2（2026-06-27 二轮，按跳蛛先生听感反馈修）
反馈：①整体偏慢 ②语调太平太冷静 ③结尾"一起来调"被念成 diào。三处各自独立修，一次重生成全修掉：
- **多音字**：`fullFilmVoiceover.ts` author_03 `一起来调`→`一起来调试`（tiáoshì 无歧义；caption=ttsText，字幕同步变「调试」）。
- **语调**：`generate-full-film-voiceover.ts` voice_settings `stability 0.52→0.35`、`style 0.22→0.38`（author 0.3→0.48），更有情绪起伏。
- **节奏**：重生成时 `FULL_FILM_VOICEOVER_PLAYBACK_RATE=1.12`（原 1.05）。
- 结果：`totalFrames 4792→4458`（2:40→**2:28**）；真片 `out/full-film-20260616-v3.1-take2.mp4`（13.4M）；抽帧确认作者话字幕「调试」+ 四卡正常。

### take3（2026-06-27 三轮，又一多音字）
反馈：结尾外又发现「调研」被念成 tiáo研（应 diào研）。按知识库既有方案修（[[2026-06-09_Remotion全片音频字幕BGM复盘_v1]] 问题一：TTS 误读就换无歧义词，caption=ttsText 不分叉）：
- `调研`→`研究`（fullFilmVoiceover.ts teaching_03 + sceneSpecs scene_02 同步）。
- 只重生成 teaching_03 一段（`FORCE_BEAT_IDS` + 保持 `PLAYBACK_RATE=1.12`，省钱不全量）。
- 结果：`totalFrames 4458→4452`；真片 `out/full-film-20260616-v3.1-take3.mp4`（13.4M / 2:28）；抽帧确认字幕「研究」。
- 顺手把该复盘文档补强：多音字误读→换词，记下 Eleven v3 对「调」的 tiáo 偏向（两个方向都可能错，最稳绕开「调」字）。
- **跳蛛先生确认其余都 OK**（语调、节奏、其它发音）。take3 即"三轮听感反馈"封口版。

### 仍待办（交回跳蛛先生）
- [ ] **审节奏**（只有亲耳听算数）：作者独白是否压到位、三误区快切是否清楚、真实翻车案例是否讲明白、2:40 整体有无拖段。
- [ ] 节奏定稿后做 P1：9 个新场景重做 MJ/Seedance（当前全是 Remotion 原生几何图形占位）。
- [ ] warning-icon 浅底白标签描边、BGM 取段/音量随新节奏微调（旧待办仍在）。

## 关联
- 文稿：`production/full_film_2026-06-16_script_v3.1_locked.md`
- 旧版工作日志：`production/full_film_2026-06-10_worklog_archive.md`
- 案例真身：`{知识库}/03_prompt模板库/02_案例复盘/2026-05-15_灵光一现+风花雪月双题复盘_v1.md`
- 两个 Skill：`aigc-postmortem/SKILL.md`（尸检）、`maieutic-skill/SKILL.md`（助产）
